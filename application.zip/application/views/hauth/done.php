<?php
	var_dump($user_profile);
?>
