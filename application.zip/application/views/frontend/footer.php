<div class="footer page">
		<div class="container">
			<div class="row" style="margin-top: 20px">
				<div class="col-md-6">
					<div class="copy nomg">
						Copyright © 2015 <a href="http://v2realestate.co/">V2 Real Estate Pvt. Ltd.</a> All right are reserved.
					</div>
				</div>
					<div class="col-md-6">
						<div class="copy nomg pull-right">
							Powered by <a href="http://wohlig.com" target="_blank">Wohlig Technology.</a>
						</div>
					</div>
			</div>
		</div>
	</div>
